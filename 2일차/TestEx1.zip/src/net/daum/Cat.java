package net.daum;

import com.naver.Dog;

public class Cat {
	
	int showInt = 5;
	Dog pDog = new Dog();
	
	boolean testBoolean;
	
	public Cat() {
		// TODO Auto-generated constructor stub
	}
	
	public void haha1(int a) {
		
	}
	
	
	

}
