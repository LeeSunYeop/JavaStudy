package kr.co.dwitt;

import net.daum.Cat;

public class Turtle {
	
	boolean isMale;
	char sex;
	int id;
	String name;
	int age;
	
	Cat cat;

}
