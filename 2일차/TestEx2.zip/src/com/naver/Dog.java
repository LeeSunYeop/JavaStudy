package com.naver;

public class Dog {
	
	public int test = 10;
	
}
