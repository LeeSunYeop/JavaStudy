package com.samsung;

public class Cat {
	
	public Cat(int a) {
		System.out.println(a);
		
		boolean b = false;
		char c = 'z';
		byte d = 127;
		short e = 300;
		int f = 21;
		long g = 3L;
		float h = 3.14f;
		double i = 9.8;
		
		String msg = new String("hello");
		
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		System.out.println(h);
		System.out.println(i);
		System.out.println(msg);
		
	
		
	}

}
