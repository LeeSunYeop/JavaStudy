package kr.co.dwitt;

public class MainEx {
	
	public static void main(String[] args){
	//public 접근제어지시자 4개 중 하나로 가장 접근을 용이하게 하는 지시자
	// static: 메서드의 저장 위치를 의미하며, 추가적인 의미가 있음
	// void: 반환형이라고 하며, 반환되는 데이터의 자료형의 약자로 반환값에 따라 달라짐
	// main: 메서드의 이름으로 해당 메서드는 자바 프로그래밍에서 반드시 있어야함
	// (): 매개변수 정의 구역
	// string[]: 매개변수를 선언할 때 사용하는 매개변수의 자료형
	// args: main()메서드의 매개변수명
		
		// String : 자료형
		// str : 변수명
		// = 대입연산자(오른쪽에 있는걸 왼쪽에 넣어주세요)
		// "hello world" : 자료형에 맞는 값
		// ; : 코드 완료
		String str = new String("hello world");
		// 변수 선언 공식
		// 자료형 변수명 = 자료형에 맞는 값;
		
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.err.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		System.out.println(str);
		
	}

}

