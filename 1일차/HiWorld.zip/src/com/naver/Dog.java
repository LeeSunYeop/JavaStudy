package com.naver;

public class Dog {
	
	

}
