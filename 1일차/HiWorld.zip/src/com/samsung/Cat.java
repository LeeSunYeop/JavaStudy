package com.samsung;

public class Cat {
	
	public Cat(int a) {
		System.out.println(a);
		
	}

}
